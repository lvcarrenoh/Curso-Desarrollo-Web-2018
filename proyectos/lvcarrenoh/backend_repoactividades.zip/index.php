<?php

/** @var \Slim\App $app */
$app = require __DIR__ . '/app/arranque.php';

$app-> run();