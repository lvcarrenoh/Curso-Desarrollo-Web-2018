<?php

// Definición de rutas de la Aplicación Web

/*$app->get('/', function($request, $response){
    echo '<h1>Página de Inicio</h1>';
});*/