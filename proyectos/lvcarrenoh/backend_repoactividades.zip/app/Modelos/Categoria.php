<?php

// Crear todo el modelo